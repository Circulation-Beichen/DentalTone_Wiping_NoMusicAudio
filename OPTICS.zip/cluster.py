import numpy as np
import librosa
import soundfile as sf
import matplotlib.pyplot as plt
import os
from sklearn.cluster import OPTICS
from sklearn.preprocessing import StandardScaler
import gymnasium as gym
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv
import warnings
warnings.filterwarnings('ignore')

# 项目根目录路径
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

class SibilanceEnv(gym.Env):
    def __init__(self, audio_path, sr=22050):
        super(SibilanceEnv, self).__init__()
        
        # 加载完整音频
        self.audio, self.sr = librosa.load(audio_path, sr=sr, duration=None)
        
        # 计算梅尔频谱图
        self.mel_spec = librosa.feature.melspectrogram(y=self.audio, sr=self.sr, n_mels=128)
        self.mel_db = librosa.power_to_db(self.mel_spec, ref=np.max)
        
        # 定义动作空间（OPTICS参数）
        self.action_space = gym.spaces.Box(
            low=np.array([0.01, 2, 0.1, 0.01, 0.01]),  # xi, min_samples, min_cluster_size, low_weight, high_weight
            high=np.array([0.1, 10, 0.5, 1.0, 10.0]),
            dtype=np.float32
        )
        
        # 定义观察空间（梅尔频谱图）
        self.observation_space = gym.spaces.Box(
            low=-80, high=0, shape=self.mel_db.shape, dtype=np.float32
        )
        
        # 目标时间点（使用完整6秒音频的时间点）
        self.target_times = [1.6, 2.5, 3.5]
        self.time_tolerance = 0.1
        
        # 计算总时间
        self.total_time = len(self.audio) / self.sr
        print(f"音频总长度: {self.total_time:.2f}秒")
        print(f"梅尔频谱图时间帧数: {self.mel_db.shape[1]}")
        print(f"梅尔频谱图频率数: {self.mel_db.shape[0]}")
        
    def reset(self, seed=None):
        super().reset(seed=seed)
        return self.mel_db, {}
        
    def step(self, action):
        # 解包动作参数
        xi, min_samples, min_cluster_size, low_weight, high_weight = action
        
        # 提取高频特征
        features = self._extract_features(low_weight, high_weight)
        
        # 使用OPTICS进行聚类
        labels = self._cluster_with_optics(features, xi, min_samples, min_cluster_size, low_weight, high_weight)
        
        # 计算奖励
        reward = self._calculate_reward(labels)
        
        # 判断是否结束
        terminated = True
        truncated = False
        
        return self.mel_db, reward, terminated, truncated, {}
    
    def _extract_features(self, low_weight, high_weight):
        # 获取时间轴
        times = librosa.frames_to_time(np.arange(self.mel_db.shape[1]), sr=self.sr)
        
        # 获取频率轴
        freqs = librosa.mel_frequencies(n_mels=128)
        
        # 创建特征矩阵
        features = []
        for t in range(self.mel_db.shape[1]):
            # 计算当前时间帧的高频能量
            high_freq_energy = np.mean(self.mel_db[freqs >= 4000, t])
            
            # 计算加权能量
            weighted_energy = 0
            for f in freqs:
                if f < 4000:
                    weight = 0
                elif f < 7000:
                    weight = low_weight
                elif f < 8000:
                    # 在7-8kHz之间平滑过渡
                    ratio = (f - 7000) / 1000
                    weight = low_weight + (high_weight - low_weight) * ratio
                else:
                    weight = high_weight
                weighted_energy += self.mel_db[int(f/self.sr*128), t] * weight
            
            features.append([times[t], high_freq_energy, weighted_energy])
        
        return np.array(features)
    
    def _cluster_with_optics(self, features, xi, min_samples, min_cluster_size, low_weight, high_weight):
        # 标准化特征
        scaler = StandardScaler()
        features_scaled = scaler.fit_transform(features)
        
        # 使用OPTICS进行聚类
        optics = OPTICS(
            xi=float(xi),
            min_samples=int(min_samples),
            min_cluster_size=float(min_cluster_size),
            metric='euclidean'
        )
        labels = optics.fit_predict(features_scaled)
        
        return labels
    
    def _calculate_reward(self, labels):
        # 获取聚类中心
        unique_labels = np.unique(labels[labels != -1])
        cluster_centers = []
        
        for label in unique_labels:
            cluster_points = np.where(labels == label)[0]
            if len(cluster_points) > 0:
                center_time = np.mean(cluster_points) / self.sr
                cluster_centers.append(center_time)
        
        # 计算与目标时间的匹配度
        reward = 0
        for target_time in self.target_times:
            matched = False
            for center_time in cluster_centers:
                if abs(center_time - target_time) <= self.time_tolerance:
                    reward += 1
                    matched = True
                    break
            if not matched:
                reward -= 1
        
        # 根据聚类数量调整奖励
        if len(cluster_centers) == 3:
            reward += 2
        elif len(cluster_centers) > 3:
            reward -= len(cluster_centers) - 3
        else:
            reward -= 3 - len(cluster_centers)
        
        # 添加时间范围奖励
        for center_time in cluster_centers:
            if 0 <= center_time <= self.total_time:
                reward += 0.5
            else:
                reward -= 1
        
        return reward

def train_agent(audio_path, output_dir):
    """训练强化学习代理"""
    # 创建环境
    env = DummyVecEnv([lambda: SibilanceEnv(audio_path)])
    
    # 创建PPO代理
    model = PPO(
        "MlpPolicy", 
        env, 
        verbose=1,
        learning_rate=3e-4,
        n_steps=2048,
        batch_size=64,
        n_epochs=10,
        gamma=0.99,
        gae_lambda=0.95,
        clip_range=0.2,
        ent_coef=0.01
    )
    
    # 训练代理
    model.learn(total_timesteps=5000)  # 增加训练步数
    
    # 保存模型
    model.save(os.path.join(output_dir, "sibilance_agent"))
    
    return model

def process_audio(audio_path, model, output_dir):
    """使用训练好的模型处理音频"""
    # 创建环境
    env = SibilanceEnv(audio_path)
    
    # 获取最优动作
    obs, _ = env.reset()
    action, _ = model.predict(obs)
    
    # 使用最优参数进行聚类
    xi, min_samples, min_cluster_size, low_weight, high_weight = action
    
    # 提取特征
    features = env._extract_features(low_weight, high_weight)
    
    # 进行聚类
    labels = env._cluster_with_optics(features, xi, min_samples, min_cluster_size, low_weight, high_weight)
    
    # 创建处理后的音频
    processed_audio = env.audio.copy()
    
    # 对每个聚类应用-7dB的负增益
    for label in np.unique(labels[labels != -1]):
        cluster_points = np.where(labels == label)[0]
        if len(cluster_points) > 0:
            # 获取聚类的时间范围
            start_time = cluster_points[0] / env.sr
            end_time = cluster_points[-1] / env.sr
            
            # 转换为样本索引
            start_sample = int(start_time * env.sr)
            end_sample = int(end_time * env.sr)
            
            # 应用负增益
            gain_factor = 10 ** (-7 / 20)  # -7dB
            processed_audio[start_sample:end_sample] *= gain_factor
    
    # 保存处理后的音频
    output_audio_path = os.path.join(output_dir, "processed_audio.mp3")
    sf.write(output_audio_path, processed_audio, env.sr)
    
    # 绘制并保存带有聚类标记的梅尔图
    plt.figure(figsize=(12, 6))
    librosa.display.specshow(env.mel_db, x_axis='time', y_axis='mel', sr=env.sr)
    plt.colorbar(format='%+2.0f dB')
    
    # 标记聚类
    for label in np.unique(labels[labels != -1]):
        cluster_points = np.where(labels == label)[0]
        if len(cluster_points) > 0:
            times = librosa.frames_to_time(cluster_points, sr=env.sr)
            plt.plot(times, [64] * len(times), 'r.', markersize=10)
    
    plt.title('带有聚类标记的梅尔频谱图')
    plt.savefig(os.path.join(output_dir, "mel_spectrogram_with_clusters.png"))
    plt.close()
    
    # 保存参数
    params = {
        'xi': xi,
        'min_samples': min_samples,
        'min_cluster_size': min_cluster_size,
        'low_weight': low_weight,
        'high_weight': high_weight,
        'total_time': env.total_time
    }
    
    with open(os.path.join(output_dir, "optimal_parameters.txt"), 'w') as f:
        for param, value in params.items():
            f.write(f"{param}: {value}\n")
    
    return processed_audio, params

def main():
    # 创建输出目录
    output_dir = os.path.join(ROOT_DIR, "OPTICSand强化学习")
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # 音频文件路径
    audio_path = os.path.join(ROOT_DIR, "原始音频片段_01.mp3")
    
    # 训练代理
    print("开始训练强化学习代理...")
    model = train_agent(audio_path, output_dir)
    
    # 处理音频
    print("使用训练好的模型处理音频...")
    processed_audio, params = process_audio(audio_path, model, output_dir)
    
    print(f"处理完成！结果保存在: {output_dir}")

if __name__ == "__main__":
    main()
